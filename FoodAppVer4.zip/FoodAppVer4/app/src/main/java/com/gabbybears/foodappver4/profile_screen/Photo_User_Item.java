package com.gabbybears.foodappver4.profile_screen;

/**
 * Created by Android on 10/24/2015.
 */
public class Photo_User_Item {
    int imageUserItem;

    public Photo_User_Item(int imageUserItem) {
        this.imageUserItem = imageUserItem;
    }

    public int getImageUserItem() {
        return imageUserItem;
    }

    public void setImageUserItem(int imageUserItem) {
        this.imageUserItem = imageUserItem;
    }
}
